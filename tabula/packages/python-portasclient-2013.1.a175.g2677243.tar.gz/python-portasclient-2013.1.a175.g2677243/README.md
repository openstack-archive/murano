Python bindings to the Portas API
=====================================

This is a client library for Portas built on the Portas API. It
provides a Python API (the ``portasclient`` module) and a command-line tool
(``portas``).